-- Snowflake: Example to scale a virtual warehouse
ALTER WAREHOUSE my_wh SET WAREHOUSE_SIZE = 'LARGE';
ALTER WAREHOUSE my_wh RESUME;