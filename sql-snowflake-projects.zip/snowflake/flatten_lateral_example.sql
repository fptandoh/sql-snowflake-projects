-- Snowflake: Using FLATTEN and LATERAL to unpack JSON
SELECT
    order_id,
    customer_name,
    order_data:order_date::DATE AS order_date,
    i.value:product::STRING AS product,
    i.value:quantity::NUMBER AS quantity
FROM customer_orders,
LATERAL FLATTEN(input => customer_orders.order_data:items) i;