-- Loan Reconciliation Stored Procedure Template
CREATE OR REPLACE PROCEDURE reconcile_loans()
RETURNS STRING
LANGUAGE SQL
AS
$$
BEGIN
    DELETE FROM reconciled_loans WHERE reconciliation_date = CURRENT_DATE;

    INSERT INTO reconciled_loans (account_id, loan_amount, balance, reconciliation_date)
    SELECT
        l.account_id,
        l.original_amount,
        t.current_balance,
        CURRENT_DATE
    FROM loans l
    JOIN loan_transactions t ON l.account_id = t.account_id
    WHERE ABS(l.original_amount - t.current_balance) < 1;

    RETURN 'Reconciliation complete.';
END;
$$;