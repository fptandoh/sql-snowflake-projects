-- Snowflake: Extracting fields from nested JSON in VARIANT column
SELECT
    event_data:id::STRING AS event_id,
    event_data:details:type::STRING AS event_type,
    event_data:details:timestamp::TIMESTAMP AS event_time
FROM raw_events;