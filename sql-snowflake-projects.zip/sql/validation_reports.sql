-- Validation Report: Missing Customer Info
SELECT
    account_number,
    customer_name,
    city,
    state
FROM operations.customers
WHERE customer_name IS NULL
   OR city IS NULL
   OR state IS NULL;