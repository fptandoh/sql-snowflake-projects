-- Exception Tracking: Duplicate Transactions
SELECT
    account_id,
    transaction_id,
    COUNT(*) AS duplicate_count
FROM transactions
GROUP BY account_id, transaction_id
HAVING COUNT(*) > 1;